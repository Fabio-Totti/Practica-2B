package Rectangulos;

//Se exportan las librerias necesarias(media.OpenGL, awt, swing)
//para la creacion de los graficos

import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;
import java.awt.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;



/**
 * Trazos.java <BR>
 * @author: Fabio
 */
public class Trazos extends JFrame{
    
   //Instanciamos las variable de Glut
    static GL gl;
    static GLU glu;
    
    //Declaramos variables enteros para almacenamiento de valores
    int a=0,b=0;
    
    //Se crea el metodo Constructor
    public Trazos (){
        
        setTitle("Rectangulos Infinitos");
        this.setExtendedState(6);
        //Instanciamos la clase Graphic
        GraphicListener listener = new GraphicListener();
        //Creamos el canvas
        GLCanvas canvas = new GLCanvas(new GLCapabilities());
        canvas.addGLEventListener(listener);
        getContentPane().add(canvas);
    } 
    
   
     public class GraphicListener implements GLEventListener{

        public void display(GLAutoDrawable arg0) {
           // Indicamos el tama�o en pixeles del grosor de la linea
           gl.glLineWidth(2);
           //Indicamos que vamos a iniciar a crear lineas
           gl.glBegin(GL.GL_LINES);
           //Asignamos un color
           gl.glColor3f(0.5f, 5.5f, 0.5f);
           
           //Se crea un bucle for para el desarrollo de formas rectangulares
           //a partir de lineas exclusivamente, en esta se asignara una anchura
           // y altura de manera progresiva a partir de la acumulacion de valores
           // en x, -x, y, -y de las vertices creando asi una grafica constante 
           //hasta cierto limite acorde a los parametros de la proyeccion.

                  for(int i = 50; i <= 1000; i = i + 50){
                  //arriba
                  gl.glVertex2d(a-i-300,b+i);
                  gl.glVertex2d(a+i+300,b+i);
                  //abajo
                  gl.glVertex2d(a-i-300,b-i);
                  gl.glVertex2d(a+i+300,b-i);
                 
                  gl.glVertex2d(a-i-300,b-i);
                  gl.glVertex2d(a-i-300,b+i);
                  
                  gl.glVertex2d(a+i+300,b-i);
                  gl.glVertex2d(a+i+300,b+i);
                 
                 
                  }

           //Deshabilitamos la creacion de lineas (de la maquina de estados )
           gl.glEnd();

           gl.glFlush();

        }

        public void init(GLAutoDrawable arg0) {
            glu = new GLU();
            gl = arg0.getGL();
            gl.glClearColor(0, 0, 0, 0);
            //Establecer los parametros para la proyeccion
            gl.glMatrixMode(gl.GL_PROJECTION);
            glu.gluOrtho2D(-1000, 1000, -700, 700);
            
        }

        public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {

        }

        public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {

        }

    }
     //Se crea el main
      public static void main (String args[]){
        Trazos frame = new Trazos();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
}
